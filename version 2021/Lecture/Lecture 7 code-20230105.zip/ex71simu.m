% Lecture 7 example 1: Simulate a Poisson process
%
% Parameters:
%    lambda   intensity parameter of the process (events per time unit)
%    n        number of events to simulate
%
function T=ex81simu(lambda, n)

% n independent interevent times
tau = exprnd(1/lambda, 1, n);

% cumulative sums:
% k'th event time is sum of k first interevent times
T = cumsum(tau);

