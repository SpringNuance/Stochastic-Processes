% Lecture 7 example 2: Plotting a sample from Poisson process
% (eg. from ex81simu)
%
function ex82plot(T)

clf
n = length(T);

subplot('position', [0.1 0.4 0.8 0.55]);
% The count of events is 0 during the interval
% from 0 to just before T(1).
plot([0, T(1)], [0 0], 'k-', 'linewidth', 2);
hold on
grid on
set(gca, 'xlim', [0 max(T)+0.5]);
set(gca, 'ylim', [0 n+0.5]);
set(gca, 'ytick', 0:n);
xlabel('time')
ylabel('cumulative #events')
title('Simulated Poisson process');

for i=1:n
    % Show the i'th event as a red dot.
    plot(T(i), i, 'ro', 'markerfacecolor', 'r', 'markersize', 8);
    
    % Show the jump as a dashed line.
    plot([T(i) T(i)], [i-1 i], 'k:');
    
    % After the i'th event,
    % from T(i) to just before T(i+1),
    % the count of events is i.
    % (But after the last, n'th, simulated
    %  event we do not know how long
    %  to the next, (n+1)'th event.)
    if i<n
        plot([T(i), T(i+1)], [i i], 'k-', 'linewidth', 3);
    end
end

% Lower panel: Show just the events.
subplot('position', [0.1 0.1 0.8 0.1]);
plot([0 max(T)+1], [0 0], 'k-');
hold on
plot(T, zeros(1,n), 'ro', 'markerfacecolor', 'r', 'markersize', 8);
set(gca, 'xlim', [0 max(T)+0.5]);
set(gca, 'ytick', []);
grid on
title(sprintf('Simulated %d events', n));

