% Lecture 7 example 3:
% How do the simulated processes look in general?
%
% Try varying lambda (the rate parameter).
% Try also varying h (the box size for studying point count distribution).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Part 1: Simulate the random process many times
lambda = 5;          % rate parameter: expected #events per time unit
n = 100;             % events to simulate
REP = 1000;          % do the whole process REP times

Trep = zeros(n,REP);

for rep=1:REP
    Trep(:, rep) = ex71simu(lambda, n)';
end

figure(1)
clf
for rep=1:REP
    plot([0;Trep(:,rep)], (0:n)');
    hold on
end
title(sprintf('%d simulations of the Poisson process', REP));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Part 2: Study point count distributions
h = 2;               % look at counts in boxes of this length
m = 4;               % look at first m boxes

Nrep = zeros(m, REP);
for rep=1:REP
    for j=1:m
        leftpoint = (j-1)*h;
        rightpoint = j*h;
        Nrep(j, rep) = sum(Trep(:,rep) > leftpoint & Trep(:,rep) <= rightpoint);
    end
end
figure(2)
clf
for j=1:m
    subplot(1,m+1,j)
    % Empirical distribution of event count in j'th box
    hist(Nrep(j,:), 0:round(5*lambda*h))
    set(gca,'xlim',[-1 max(5,round(3*lambda*h))]);
    title(sprintf('pts in box %d', j))
end

% Show true Poisson distribution for comparison
subplot(1,m+1,m+1)
x = 0:round(5*lambda*h);
f = poisspdf(x, lambda*h);
bar(x,f);
set(gca,'xlim',[-1 max(5,round(3*lambda*h))]);
title(sprintf('Poisson(%.3g)', lambda*h));
