% Lecture 4 example 2: Gambler's ruin
% Hitting probability to target (M) when starting
% from each of the states.
%
% Parameters:
% M = target state (states are 0 to M)
% q = winning probability on each round
%
function h=ex42gambler(M,q)

if nargin<1, M=5; end
if nargin<2, q=0.5; end

x = 0:M;   % All states

if q==0.5
    % Symmetric case
    h = x/M;
else
    % Asymmetric case
    alpha = (1-q)/q;
    h = (alpha.^x - 1) ./ (alpha^M - 1);
end

clf
plot(x, h, 'ro-', ...
    'markerfacecolor', 'r', 'linewidth', 2);
grid on

