% Lecture 4 example 1: HR management, passage time

% Here number "exit" as state 4 (was 0 in lectures),
% to make it easier: state 1 is 1, 2 is 2, 3 is 3.

P = [0.950 0.030 0     0.020;
     0     0.982 0.010 0.008;
     0     0     0.990 0.010;
     0     0     0     1;];

% Expected passage time to state 4 (exit).
A     = [4];
ylist = setdiff(1:4, A);   % states not in A
ny    = length(ylist);     % #states not in A

% Set up a linear system for solving the
% simultaneous equations.
D     = P(ylist, ylist) - eye(ny,ny);

% Apply matrix division to solve it.
% These are the expected passage times
% to set A starting from each state outside A.
k     = D \ -ones(ny,1)


