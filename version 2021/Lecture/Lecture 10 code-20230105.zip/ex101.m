% Lecture 10 example 1
% Two machines breaking and repaired randomly.

lambda = 1/40;      % rate of breaking (per week per machine)
kappa  = 1/2;       % rate of repairing (per week per machine)

Q = [-2*lambda 2*lambda 0;
    kappa -(lambda+kappa) lambda;
    0 2*kappa -2*kappa]

% Transition matrix for 3 weeks
P3 = expm(3*Q)
