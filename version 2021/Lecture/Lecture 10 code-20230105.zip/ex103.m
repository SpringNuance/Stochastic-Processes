% Lecture 10 example 3
% Two-core cpu plus one waiting slot, thus max 3 jobs in the system.

% States are 0,1,2,3 (tasks in the system).
S      = [0 1 2 3];
lambda = 12;   % rate of tasks arriving (per hour)
kappa  = 4;    % rate of tasks finishing (per hour per task being run)

Q = [-lambda lambda 0 0;
    kappa -lambda-kappa lambda 0;
    0 2*kappa -lambda-2*kappa lambda;
    0 0 2*kappa -2*kappa]

% Solve the balance equation.
% Here "pi" denotes the distribution, not 3.14.
% We want pi*Q = zero vector,
% or by transposing, Q' * pi' = zero vector.
n = length(Q);
A = Q';
b = zeros(n,1);
% Add one more equation: We also want sum(pi)=1.
A = [A; ones(1,n)];
b = [b; 1];
pitrans = linsolve(A,b);
pi = pitrans'


% Illustrate time evolution if starting from
% state 0 (no tasks).
mu0 = [1 0 0 0];
clf
npoints = 200;
timelist = linspace(0, 1, npoints);
mulist = zeros(npoints, length(S));
for i=1:npoints
    t   = timelist(i);
    Pt  = expm(t*Q);
    mut = mu0*Pt;
    mulist(i,:) = mut;
end
plot(timelist, mulist, '-', 'linewidth', 2);
set(gca,'fontsize',20);
legendtext = {};
for x=S
    legendtext = [legendtext {sprintf('%d jobs',x)}];
end
legend(legendtext)
grid on
xlabel('t [hours]');
ylabel('state probability');
title('Two-core cpu evolution');

% State distribution after 1 hour.
% Compare to invariant distribution solved earlier.
% Not quite steady state yet!
mu1 = mu0 * expm(1*Q)

% State distribution after 10 hours.
mu10 = mu0 * expm(10*Q)
