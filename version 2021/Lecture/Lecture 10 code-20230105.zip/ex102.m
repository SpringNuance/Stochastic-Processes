% Lecture 10 example 2
% Two machines continued (run ex101 first)

% Solve the balance equation.
% Here "pi" denotes the distribution, not 3.14.
% We want pi*Q = zero vector,
% or by transposing, Q' * pi' = zero vector.
n = length(Q);
A = Q';
b = zeros(n,1);
% Add one more equation: We also want sum(pi)=1.
A = [A; ones(1,n)];
b = [b; 1];
pitrans = linsolve(A,b);
pi = pitrans'

