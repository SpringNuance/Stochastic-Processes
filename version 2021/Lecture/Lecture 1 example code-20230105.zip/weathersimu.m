% Weather simulation: Lecture notes 1.7
%
% Simulate days 0...n, if cloudy on day 0.
%
% Try e.g. xlist=weathersimu(100, false)
% to simulate 100 consecutive rows.
% Then sum(xlist==2) tells you how many days
% were sunny in that simulation!
%
function xlist = weathersimu(n, verbose)
if nargin<2, verbose=true; end

% Transition matrix
P = [0.8 0.2; 0.5 0.5];
% Initial distribution: Cloudy with certainty.
x = 1;
xlist = [x];

for i=1:n
    % Pick next weather randomly, using probabilities
    % from the relevant row of transition matrix.
    row = P(x,:);
    if verbose
        fprintf('Day %d is %d. Simulating next with probs %.3f,%.3f ...\n',...
            i-1, x, row(1), row(2));
        pause
    end
    U = rand;       % Random number uniformly in interval (0,1).
    if U < row(1)
        % This will happen with probability row(1)=0.8,
        % because that is the probability that U happens
        % to be in the interval (0, 0.8).
        x = 1;
    else
        % This happens otherwise, that is, with proability
        % 1-0.8 = 0.2.
        x = 2;
    end
    if verbose
        fprintf('            U=%.3f, so next day weather is %d\n\n', U, x);
        pause
    end
    xlist = [xlist x];
end
