% Transient distributions: Lecture notes 1.3

% Transition matrix
P = [0.8 0.2; 0.5 0.5];

% Initial distribution on Monday: Cloudy.
fprintf('Monday:\n');
mu0 = [.5 .5]
pause

% Predict Tuesday
fprintf('Tuesday:\n');
mu1 = mu0 * P
pause

% Predict Wednesday (2 days ahead)
fprintf('Wednesday:\n');
mu2 = mu1 * P         % From Tue to Wed, one step
mu2 = mu0 * P * P     % From Mon to Wed, two steps directly
pause

% Predict Saturday (5 days ahead)
fprintf('Saturday:\n');
mu5 = mu0 * P*P*P*P*P % Taking 5 steps forward
mu5 = mu0 * P^5       % Yet another way of writing it
