% Path probabilities: Lecture notes 1.5

% Transition matrix
P = [0.8 0.2; 0.5 0.5];

% Initial distribution on Monday: Cloudy.
fprintf('Monday: Cloudy with probability\n');
pc1 = 1
pause

fprintf('Cloudy Mon-Tue (2 days)\n')
pc2 = pc0 * P(1,1)
pause

fprintf('Cloudy Mon-Wed (3 days)\n')
pc3 = pc0 * P(1,1) * P(1,1)
pause

fprintf('Cloudy Mon-Sat (6 days)\n')
pc6 = pc0 * P(1,1)^5
pause

fprintf('Cloudy for 21 days\n')
pc21 = pc0 * P(1,1)^20
