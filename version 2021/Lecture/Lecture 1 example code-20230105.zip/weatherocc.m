% Occupancy: Lecture notes 1.6

% Transition matrix
P = [0.8 0.2; 0.5 0.5];
I = eye(2);   % identity matrix

fprintf('Occupancy matrix for Monday only\n');
M1 = I
pause

fprintf('Occupancy matrix for Mon-Tue (2 days)\n');
M2 = I + P
pause

fprintf('Occupancy matrix for Mon-Wed (3 days)\n');
M3 = I + P + P^2
pause

fprintf('Occupancy matrix for Mon-Sat (7 days)\n');
M7 = I + P + P^2 + P^3 + P^4 + P^5 + P^6
pause
