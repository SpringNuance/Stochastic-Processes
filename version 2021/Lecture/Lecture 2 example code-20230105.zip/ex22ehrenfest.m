% Lecture 2 example 2: Ehrenfest urn

N = 20;

% Note that we have N+1 states
% (from 0 to N). We store them
% in rows and columns 1 to N+1
% because Matlab matrices work
% that way. So state i goes to
% row and column i+1.
P = zeros(N+1, N+1);

for i=0:N
    % If left box has i particles,
    % with i/N probability it decreases
    % and with 1-that it increases.
    %
    % All row and column indices have +1
    % (see above for reason).
    if i>0
        P(i+1, i-1+1) = i/N;
    end
    if i<N
        P(i+1, i+1+1) = 1 - i/N;
    end
end

% Start with all particles in the left box,
% that is, state N with certainty.
mu = [zeros(1,N) 1];
fprintf('t=%-3d  ', 0);
disp(mu);

% Let us see how it evolves.
for t=1:100
    mu = mu*P;
    fprintf('t=%-3d  ', t);
    disp(mu);
end
