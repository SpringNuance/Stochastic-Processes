% Lecture 2 example 4: checking convergence

P = [0 1 0; 1/2 0 1/2; 1 0 0]

% Try iterating many times
fprintf('15-step transition matrix:\n')
P^15
pause
fprintf('100-step transition matrix:\n')
P^100
pause

% Find an invariant distribution (cf. example 1)
fprintf('Invariant distribution:\n');
[V,~] = eig(P')     % Transpose because EIG gives right eigenvectors.
p = V(:,1)'         % First eigenvector
p = p/sum(p)        % Normalize eigenvector to sum=1.


