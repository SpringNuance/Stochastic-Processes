% Lecture 2 example 5: Reducible (not strongly connected)

P = [1 0 0 0 0;
    1/3 0 1/3 1/3 0;
    0 2/3 0 0 1/3;
    0 0 0 2/3 1/3;
    0 0 0 2/3 1/3];

