% Lecture 2 example 3: Many limits

P = [0.5 0.5 0; 0.5 0.5 0; 0 0 1];

P
P^2

[1 0 0]*P
[0 0 1]*P

