% Lecture 2 example 1: Brand loyalty

P = [.8 .1 .1;
     .2 .6 .2;
     .3 .3 .4];

mu = [1 0 0];
for i=1:100
    mu = mu*P;
    disp(mu);
end

% What is the first left eigenvector?
[V,~] = eig(P')     % Transpose because EIG gives right eigenvectors.
p = V(:,1)'         % First eigenvector
p = p/sum(p)        % Normalize eigenvector to sum=1.
