% Lecture 5 example 2: How does a birth-death process evolve
%
% In this example we start from a known state.
% In one step we can at most go right one step, so at any
% finite time we still have a finite set of POSSIBLE states.
%
% Parameters:
%   p   Probability of moving right (default 0.4)
%   x0  Initial sstate (default 2)
%
% Try for example p=0.4, p=0.5, p=0.9.
%
function ex5birthdeath(p, x0)

if nargin<1, p=0.4; end
if nargin<2, x0=2; end

q   = 1-p;
mu0 = [zeros(1,x0) 1];  % Initial state distribution
mu  = mu0;

% Transition matrix, finite truncation:
% we only consider states 0 to x0+1.
P = diag(repmat(p,x0+1,1),1) ...
    + diag(repmat(q,x0+1,1),-1);
P(1,1)=q;
% This is not a true transition matrix
% because the last row (from state x0+1)
% does not sum to one. That does not matter
% because we are not in state x0+1.

t = 0;
while true
    % Plot distribution at time t.
    % Possible states are from 0 to x0+t.
    S = 0:(x0+t);
    bar(S, mu);
    
    % Limit the display so that approx 99%
    % of the distribution mass is shown
    % (and a bit further).
    maxstateshow = find(cumsum(mu) >= 0.999, 1);
    set(gca,'xlim',[-0.5 maxstateshow + 10]);
    title(sprintf('Time t=%d', t));

    pause
    
    % Apply the truncated transition matrix.
    % First extend the state distribution
    % with one more state so that we can move there.
    mu = [mu 0];
    mu = mu*P;

    % Extend the truncated transition matrix
    % because we may have moved one step right.
    m = size(P,1);
    P = [P zeros(m,1); zeros(1,m+1)];
    P(end-1,end) = p;
    P(end,end-1) = q;
    
    t = t+1;
end
