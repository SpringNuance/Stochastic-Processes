% Lecture 5 example 1: Simple Markov chain NOT in detailed balance
% (unless p=1/2)
%
% Three states in a circle, clockwise 1,2,3;
% possibly different probabilities going
% clockwise (p) and anticlockwise (q=1-p).

function ex51circular(p)

if nargin<1, p=0.9; end
q = 1-p;

P = [0 p q;
     q 0 p;
     p q 0];
 
% Is there an invariant distribution?
[V,D] = eig(P');    % Transpose because EIG gives right eigenvectors.
i = find(abs(diag(D)-1) < 1e-6);        % Do we have 1 as eigenvalue?
p = V(:,i)';        % Take that eigenvector
p = p/sum(p)        % Normalize eigenvector to sum=1.
% Now p is an invariant distribution!

% Does it have a limiting distribution starting from 1?
% Let's just apply P many times.
mu0 = [1 0 0];
mu  = mu0 * P^100

% Is it in detailed balance?
% Let us just inspect between states 1 and 2.
lhs = p(1)*P(1,2)
rhs = p(2)*P(2,1)
fprintf('detailed balance? ');
if abs(lhs-rhs) < 1e-6
    fprintf('YES\n');
else
    fprintf('NO\n');
end


